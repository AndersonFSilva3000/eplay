import React from 'react'

import {GlobalCss} from './styles'

function App() {
  return (
    <>
      <GlobalCss />
      <div>
        <h1>Olá mundo</h1>
      </div>
    </>
  )
}

export default App
